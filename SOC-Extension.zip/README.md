# SOC-Extension

A WIP web extension to organise SOC tools