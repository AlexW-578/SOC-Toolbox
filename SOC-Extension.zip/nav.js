$(function () {
    $("#includedContent").load("/nav.html");
});